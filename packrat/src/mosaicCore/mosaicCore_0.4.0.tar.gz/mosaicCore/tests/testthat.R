library(testthat)
library(mosaicCore)

test_check("mosaicCore")
