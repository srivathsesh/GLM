
double C_maxabsTestStatistic (const double *t, const double *mu, const double *Sigma,
                              int pq, double tol);
